####################################
# Author    :   Devulapalli, Vijay
# Version   :   1.0
####################################
from flask import Flask, request, jsonify, send_file, render_template, redirect, url_for
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user
from encryption import encrypt_file, decrypt_file
from minio import Minio
import json
import os
import io

# Initialize Flask app
app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Configure upload folder
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Set up Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'home'

# In-memory user store (for simplicity)
users = {}

# User class
class User(UserMixin):
    def __init__(self, id):
        self.id = id

@login_manager.user_loader
def load_user(user_id):
    if user_id in users:
        return User(user_id)
    return None

# Routes
@app.route('/', methods=['GET', 'POST'])
def home():
    return render_template('index.html')

@app.route('/dashboard')
@login_required
def dashboard():
    local_files = os.listdir(app.config['UPLOAD_FOLDER'])
    cloud_files_list = []
    try:
        bucket_name = "cloud-file-enc-bucket"
        if minio_client.bucket_exists(bucket_name):
            objects = minio_client.list_objects(bucket_name, recursive=True)
            cloud_files_list = [obj.object_name for obj in objects]
    except Exception as e:
        print(f"Could not list cloud files: {e}")

    return render_template('dashboard.html', files=local_files, cloud_files=cloud_files_list)

@app.route('/upload_reports', methods=['GET'])
@login_required
def upload_reports():
    return render_template('upload_reports.html')

@app.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    password = request.form['password']
    if username in users:
        return jsonify({'message': 'User already exists!'}), 400
    users[username] = password
    return redirect(url_for('home'))

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    if username in users and users[username] == password:
        user = User(username)
        login_user(user)
        return redirect(url_for('dashboard'))
    return jsonify({'message': 'Invalid credentials!'}), 401

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

#==============================
# Local file management section
#==============================

@app.route('/upload', methods=['POST'])
@login_required
def upload_file():
    files = request.files.getlist('files[]')
    if not files or files[0].filename == '':
        return jsonify({'message': 'No file uploaded!'}), 400
    for file in files:
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        encrypt_file(file.read(), filepath)
    return redirect(url_for('dashboard'))

@app.route('/download/<filename>', methods=['GET'])
@login_required
def download_file(filename):
    # Prevent path traversal attacks
    safe_filename = os.path.basename(filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], safe_filename)
    try:
        if not os.path.exists(filepath):
            return jsonify({'message': 'File not found'}), 404
        decrypted_data = decrypt_file(filepath)
        if not isinstance(decrypted_data, (bytes, bytearray)):
            return jsonify({'message': 'Decryption failed or returned invalid data'}), 500
        file_stream = io.BytesIO(decrypted_data)
        file_stream.seek(0)
        return send_file(
            file_stream,
            as_attachment=True,
            download_name=f"decrypted_{safe_filename}",
            mimetype='application/octet-stream'
        )
    except Exception as e:
        return jsonify({'message': f'Error: {str(e)}'}), 500

@app.route('/download-encrypted/<filename>', methods=['GET'])
@login_required
def download_encrypted_file(filename):
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    try:
        return send_file(
            filepath,
            as_attachment=True,
            download_name=f"encrypted_{filename}",
            mimetype='application/octet-stream'
        )
    except FileNotFoundError:
        return jsonify({'message': 'File not found'}), 404

@app.route('/delete_local/<filename>', methods=['POST'])
@login_required
def delete_local_file(filename):
    safe_filename = os.path.basename(filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], safe_filename)
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
            return '', 204
        else:
            return jsonify({'message': 'File not found.'}), 404
    except Exception as e:
        return jsonify({'message': f'Error deleting file: {str(e)}'}), 500

# @app.route('/decrypt_files', methods=['POST'])
# @login_required
# def decrypt_files():
#     files = request.files.getlist('files')
#     if not files or files[0].filename == '':
#         return jsonify({'message': 'No file uploaded!'}), 400

#     decrypted_files = []
#     for file in files:
#         filename = file.filename
#         # Save uploaded encrypted file temporarily
#         temp_path = os.path.join(app.config['UPLOAD_FOLDER'], f"temp_{filename}")
#         file.save(temp_path)
#         try:
#             decrypted_data = decrypt_file(temp_path)
#             decrypted_files.append((filename, decrypted_data))
#         except Exception as e:
#             os.remove(temp_path)
#             return jsonify({'message': f'Error decrypting {filename}: {str(e)}'}), 500
#         os.remove(temp_path)

#     # If only one file, send directly; else, zip and send
#     if len(decrypted_files) == 1:
#         filename, data = decrypted_files[0]
#         return send_file(
#             io.BytesIO(data),
#             as_attachment=True,
#             download_name=f"decrypted_{filename}",
#             mimetype='application/octet-stream'
#         )
#     else:
#         zip_stream = io.BytesIO()
#         with zipfile.ZipFile(zip_stream, 'w') as zf:
#             for filename, data in decrypted_files:
#                 zf.writestr(f"decrypted_{filename}", data)
#         zip_stream.seek(0)
#         return send_file(
#             zip_stream,
#             as_attachment=True,
#             download_name="decrypted_files.zip",
#             mimetype='application/zip'
#         )

#==============================
# Cloud file management section
#==============================
#Initialize MinIO Cloud Storage client

with open(os.path.join(os.path.dirname(__file__), 'credentials.json'), 'r') as f:
    credentials = json.load(f)

minio_config = credentials.get('minio', {})
endpoint = minio_config.get('endpoint')
access_key = minio_config.get('access_key')
secret_key = minio_config.get('secret_key')

if not all([endpoint, access_key, secret_key]):
    raise ValueError("MinIO credentials not found in credentials.json")

minio_client = Minio(endpoint, access_key=access_key, secret_key=secret_key, secure=True)


@app.route('/upload_to_cloud', methods=['POST'])
@login_required
def upload_to_cloud():
    files = request.files.getlist('files[]')
    if not files or files[0].filename == '':
        return jsonify({'message': 'No file uploaded!'}), 400

    bucket_name = "cloud-file-enc-bucket"
    try:
        if not minio_client.bucket_exists(bucket_name):
            minio_client.make_bucket(bucket_name)
        for file in files:
            filename = file.filename
            local_filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            # Encrypt and save locally first
            encrypt_file(file.read(), local_filepath)
            # Upload the encrypted file to MinIO
            minio_client.fput_object(bucket_name, filename, local_filepath)
            # Optionally remove local copy after upload
            # os.remove(local_filepath)
        return redirect(url_for('dashboard'))
    except Exception as e:
        return jsonify({'message': f'Error uploading to MinIO: {str(e)}'}), 500

@app.route('/download-from-cloud/<filename>', methods=['GET'])
@login_required
def download_from_cloud(filename):
    safe_filename = os.path.basename(filename)
    local_filepath = os.path.join(app.config['UPLOAD_FOLDER'], safe_filename)
    bucket_name = "cloud-file-enc-bucket"
    try:
        # Download encrypted file from MinIO
        minio_client.fget_object(bucket_name, safe_filename, local_filepath)
        # Decrypt the downloaded file
        decrypted_data = decrypt_file(local_filepath)
        # Optionally remove the local encrypted file after decryption
        os.remove(local_filepath)
        return send_file(
            io.BytesIO(decrypted_data),
            as_attachment=True,
            download_name=f"decrypted_{safe_filename}",
            mimetype='application/octet-stream'
        )
    except Exception as e:
        return jsonify({'message': f'Error downloading from MinIO: {str(e)}'}), 500

@app.route('/download-encrypted-from-cloud/<filename>', methods=['GET'])
@login_required
def download_encrypted_from_cloud(filename):
    try:
        bucket_name = "cloud-file-enc-bucket"
        response = minio_client.get_object(bucket_name, filename)
        return send_file(
            response,
            as_attachment=True,
            download_name=f"encrypted_{filename}",
            mimetype='application/octet-stream'
        )
    except Exception as e:
        return jsonify({'message': f'Error downloading encrypted file from MinIO: {str(e)}'}), 500
    finally:
        if 'response' in locals() and response:
            response.close()
            response.release_conn()

if __name__ == '__main__':
    app.run(debug=True)