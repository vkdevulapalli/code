####################################
# Author    :   Devulapalli, Vijay
# Version   :   1.0
####################################
from cryptography.fernet import Fernet
import os

KEY_FILE = 'secret.key'

def load_or_generate_key():
    """Loads a key from a file or generates a new one if it doesn't exist."""
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, 'rb') as key_file:
            return key_file.read()
    else:
        key = Fernet.generate_key()
        with open(KEY_FILE, 'wb') as key_file:
            key_file.write(key)
        return key

# Generate and store the key securely
key = load_or_generate_key()
cipher = Fernet(key)

def encrypt_file(data, filepath=None):
    """Encrypts data. If filepath is provided, writes to file. Otherwise, returns encrypted data."""
    encrypted_data = cipher.encrypt(data)
    if filepath:
        with open(filepath, 'wb') as file:
            file.write(encrypted_data)
    return encrypted_data

def decrypt_file(encrypted_data):
    """Decrypts data."""
    return cipher.decrypt(encrypted_data)

# def encrypt_file(data, filepath):
#     encrypted_data = cipher.encrypt(data)
#     with open(filepath, 'wb') as file:
#         file.write(encrypted_data)

# def decrypt_file(filepath):
#     """Reads an encrypted file and returns its decrypted data."""
#     with open(filepath, 'rb') as file:
#         return decrypt_data(file.read())
