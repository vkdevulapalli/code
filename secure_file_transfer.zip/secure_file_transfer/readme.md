# Cloud Secure File Sharing and Monitoring System

## Overview

The **Cloud Secure File Sharing and Monitoring System** is a Python-based project that provides a secure platform for uploading, storing, and downloading files to cloud storage engines with encryption and decryption capabilities. It uses **AES symmetric encryption** (via the `cryptography` library) to ensure file confidentiality, integrity, and security. The system supports user authentication, role-based access control, and now includes **audit logging for user uploads**. It is scalable and can integrate with Vault systems for secure key storage and OAuth2.0 for authentication.

## Core Functionalities

- **File Encryption and Upload**:
  - Encrypts files using AES (via the `cryptography` library).
  - Stores encrypted files in a secure `uploads` directory.
  - Supports uploading files to cloud storage.
  - **Audit Logging for User Uploads**: Every file upload is logged with user details and timestamps.

- **Decrypted File Download**:
  - Decrypts files on-the-fly and serves them as plaintext to authorized users.

- **Encrypted File Download**:
  - Allows users to download the raw encrypted file for secure sharing.

- **User Authentication**:
  - Supports user registration, login, and logout using `Flask-Login`.
  - Supports authentication using OAuth2.0.

- **Dashboard Interface**:
  - User-friendly dashboard for uploading, viewing, and downloading files (both encrypted and decrypted).

- **Cloud Storage Integration**:
  - Supports uploading files to cloud storage engines like AWS S3, Google Cloud Storage, or MinIO.

- **Role-based Access Control**:
  - Manages file operations based on user roles.

- **Audit Logging**:
  - Tracks all file uploads, downloads, and modifications with detailed logs, including user actions.

- **Administrator Interface**:
  - Manage user accounts, file permissions, and system settings.

- **Scalability & Security**:
  - Designed for horizontal scaling.
  - Uses secure key storage solutions (AWS Secrets Manager, HashiCorp Vault).

- **Documentation & Testing**:
  - Detailed documentation for users, developers, and admins.
  - Automated unit, integration, and end-to-end tests.

- **Resilience & Performance**:
  - Load balancing, redundancy, failure detection, caching, and efficient algorithms.

- **Monitoring & Alerting**:
  - Detects and responds to system issues.

- **Patch Management & Backup**:
  - Regular updates and backup/disaster recovery strategies.

- **Data Privacy & Continuous Improvement**:
  - Complies with GDPR/CCPA.
  - Regular reviews and improvements.

## Technical Details

### Encryption and Decryption

The project uses **Fernet encryption** from the `cryptography` library:

- AES encryption in CBC mode with PKCS7 padding.
- Secure HMAC for data integrity.
- Randomized IVs for each encryption.

**Key Management:**  
A single, persistent encryption key is generated once and stored securely (never in version control). Load it from an environment variable or a secrets manager.

Generate a key:
```bash
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Example implementation (`encryption.py`):
```python
from cryptography.fernet import Fernet
import os

ENCRYPTION_KEY = os.getenv('APP_ENCRYPTION_KEY')
if not ENCRYPTION_KEY:
    raise ValueError("No APP_ENCRYPTION_KEY set for Flask application")

cipher = Fernet(ENCRYPTION_KEY.encode())

def encrypt_data(data: bytes) -> bytes:
    return cipher.encrypt(data)

def decrypt_data(encrypted_data: bytes) -> bytes:
    return cipher.decrypt(encrypted_data)
```

### Flask Application Structure

This project uses Flask for a RESTful API and dashboard.

#### Key Components

- `main.py`: Routes for authentication, file upload/download, and audit logging.
- `auth.py`: User authentication logic.
- `encryption.py`: Encryption/decryption logic.
- Templates: `index.html`, `dashboard.html`.
- Static Files: `styles.css`, `scripts.js`.

## Folder Structure

```
```
SecureFileSharing/
│
├── main.py                 # Main Flask application
├── auth.py                 # User authentication logic
├── encryption.py           # Encryption and decryption logic
├── config.py               # Configuration settings
├── uploads/                # Directory for encrypted files
├── templates/              # HTML templates
│   ├── index.html          # Login/Register page
│   ├── dashboard.html      # User dashboard
│   ├── upload_reports.html # User upload auditing
├── static/                 # CSS, JavaScript
│   ├── styles.css
│   ├── scripts.js
├── requirements.txt        # Python dependencies
└── README.md               # Documentation
```
```

## Setup Instructions

### Prerequisites

- Python 3.9 or higher
- Pip

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/secure-file-sharing.git
   cd secure-file-sharing
   ```

2. Create and activate a virtual environment:
   ```bash
   python -m venv env
   source env/bin/activate   # On Windows: env\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Run the application:
   ```bash
   python main.py
   ```

5. Access the app at [http://127.0.0.1:5000](http://127.0.0.1:5000).

## Usage

### Upload Files

- Log in using your credentials.
- Use the dashboard to upload files (local or cloud). All uploads are encrypted and **audited**.

### Download Files

- **Decrypted File**: Download plaintext version.
- **Encrypted File**: Download raw encrypted file.

### Authentication

- Register a new user account.
- Login to access the dashboard.
- Logout to end the session.

## Technical Highlights

- **AES Encryption**: Industry-standard security.
- **Flask-Login**: Simplified authentication.
- **Responsive UI**: Clean dashboard.
- **Secure Key Management**: Persistent Fernet key from a secure location.
- **Audit Logging**: All user uploads and actions are logged.

## Future Enhancements

- **Role-Based Access Control**: Advanced permissions.
- **Cloud Integration**: Expand to AWS S3, Azure Blob Storage.
- **Audit Logging**: Further detail for user actions.
- **Enhanced Key Management**: Use AWS Secrets Manager or HashiCorp Vault.

## SEO Optimized Keywords

- Secure file sharing
- AES encryption Python
- Flask file upload example
- Python file encryption project
- Encrypted file sharing application
- Flask dashboard example

## Author

**Devulapalli, Vijay**
