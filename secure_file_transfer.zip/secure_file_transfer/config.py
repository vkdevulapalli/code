import os

# Configuration file
UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')
SECRET_KEY = 'your_secret_key'
MINIO_BUCKET_NAME = 'cloud-file-enc-bucket'
CREDENTIALS_FILE = 'credentials.json'
