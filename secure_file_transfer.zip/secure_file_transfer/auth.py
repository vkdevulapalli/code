####################################
# Author    :   Devulapalli, Vijay
# Version   :   1.0
####################################
from flask_login import UserMixin, login_user, logout_user
from flask import jsonify
import os
import json

CREDENTIALS_FILE = 'credentials.json'

# In-memory user store
users = {}

class User(UserMixin):
    def __init__(self, id):
        self.id = id

def get_user(user_id):
    if user_id in users:
        return User(user_id)
    return None

def register_user(request):
    data = request.json
    username = data.get('username')
    password = data.get('password')
    if username in users:
        return jsonify({'message': 'User already exists!'}), 400
    users[username] = password
    return jsonify({'message': 'User registered successfully!'})

def login_user_func(request):
    data = request.json
    username = data.get('username')
    password = data.get('password')
    if username in users and users[username] == password:
        user = User(username)
        login_user(user)
        return jsonify({'message': 'Login successful!'})
    return jsonify({'message': 'Invalid credentials!'}), 401

def logout_user_func():
    logout_user()
    return jsonify({'message': 'Logged out successfully!'})

def load_credentials():
    if os.path.exists(CREDENTIALS_FILE):
        with open(CREDENTIALS_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_credentials(credentials):
    with open(CREDENTIALS_FILE, 'w') as f:
        json.dump(credentials, f, indent=4)

def register_user(request):
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    credentials = load_credentials()
    if username in credentials:
        return jsonify({'message': 'User already exists!'}), 400
    
    credentials[username] = password
    save_credentials(credentials)
    return jsonify({'message': 'User registered successfully!'})

def login_user_func(request):
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    credentials = load_credentials()
    if username in credentials and credentials[username] == password:
        user = User(username)
        login_user(user)
        return jsonify({'message': 'Login successful!'})
    return jsonify({'message': 'Invalid credentials!'}), 401
def load_users_from_file():
    global users
    if os.path.exists(CREDENTIALS_FILE):
        with open(CREDENTIALS_FILE, 'r') as f:
            users = json.load(f)

def save_users_to_file():
    with open(CREDENTIALS_FILE, 'w') as f:
        json.dump(users, f, indent=4)

# Load users when the module is imported
load_users_from_file()
