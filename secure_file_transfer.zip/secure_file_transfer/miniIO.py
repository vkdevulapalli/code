####################################
# Author    :   Devulapalli, Vijay
# Version   :   1.0
####################################
from minio import Minio
import json

with open('credentials.json', 'r') as f:
    credentials = json.load(f)

minio_config = credentials.get('minio', {})
endpoint = minio_config.get('endpoint')
access_key = minio_config.get('access_key')
secret_key = minio_config.get('secret_key')

# print(endpoint, access_key, secret_key)

if not all([endpoint, access_key, secret_key]):
    raise ValueError("MinIO credentials not found in credentials.json")

client = Minio(endpoint, access_key=access_key, secret_key=secret_key, secure=True)
# print("Total Buckets count :", len(client.list_buckets()))
# for bucket in client.list_buckets():
#     print(bucket.name)

def create_bucket(bucket_name):
    """Creates a bucket if it does not already exist."""
    try:
        found = client.bucket_exists(bucket_name)
        if not found:
            client.make_bucket(bucket_name)
            print(f"Bucket '{bucket_name}' created successfully.")
        # else:
        #     print(f"Bucket '{bucket_name}' already exists.")
    except Exception as e:
        print(f"Error checking or creating bucket '{bucket_name}': {e}")

def upload_file_to_bucket(bucket_name, object_name, file_path):
    try:
        client.fput_object(bucket_name, object_name, file_path)
        print(f"File '{file_path}' uploaded to '{bucket_name}/{object_name}' successfully.")
        get_files_in_bucket(bucket_name)
    except Exception as e:
        print(f"Error uploading file '{file_path}': {e}")

def download_object_from_bucket(bucket_name, object_name, file_path):
    """
    Downloads an object from a bucket to a local file.
    """
    try:
        response = client.fget_object(bucket_name, object_name, file_path)
        print(f"Downloaded '{object_name}' from bucket '{bucket_name}' to '{file_path}'.")
        return response
    except Exception as e:
        print(f"Error downloading object '{object_name}' from bucket '{bucket_name}': {e}")
        return None
    
def get_files_in_bucket(bucket_name):
    if not client.bucket_exists(bucket_name):
        print(f"Bucket '{bucket_name}' does not exist.")
        create_bucket(bucket_name='cloud-file-enc-bucket')
        print(f"Bucket '{bucket_name}' created successfully.")
        return []
    try:
        objects = client.list_objects(bucket_name, recursive=True)
        file_names = [obj.object_name for obj in objects]
        if file_names:
            print(f"Files in bucket '{bucket_name}':")
            for file_name in file_names:
                print(file_name)
        else:
            print(f"No files found in bucket '{bucket_name}'.")
    except Exception as e:
        print(f"Error listing objects in bucket {bucket_name}: {e}")
        return []
 
def remove_files_from_bucket(bucket_name, file_name):

    if not client.bucket_exists(bucket_name):
        print(f"Bucket '{bucket_name}' does not exist.")
        return []
    else:
        print(f"Bucket '{bucket_name}' exists. Proceeding further!")
    try:
        # get_files_in_bucket returns a list of object names, or None if an error occurs.
        # We need to handle the None case.
        objects_in_bucket = client.list_objects(bucket_name, recursive=True)
        file_names = [obj.object_name for obj in objects_in_bucket]

        if not file_name:
            for file in file_names:
                client.remove_object(bucket_name, file)
                print(f"File '{file}' removed from bucket '{bucket_name}'.")
        else:
            if file_name in file_names: # Check if the specific file exists before attempting to remove
                client.remove_object(bucket_name, file_name)
                print(f"File '{file_name}' removed from bucket '{bucket_name}'.")
        get_files_in_bucket(bucket_name) # Call get_files_in_bucket to print remaining files
    except Exception as e:
        print(f"Error removing files from bucket '{bucket_name}': {e}")
 
# Functions calling
#upload_file_to_bucket(file_path=r'C:\Users\shiva\PycharmProjects\secure-file-sharing\dummy_file_upload.txt', bucket_name='cloud-file-enc-bucket', object_name='dummy_file_upload.txt')
#get_files_in_bucket(bucket_name='cloud-file-enc-bucket')
#create_bucket(bucket_name='cloud-file-enc-bucket')
#remove_files_from_bucket(bucket_name='cloud-file-enc-bucket', file_name='AnnaPrasana.jpeg')
#client.remove_object('cloud-file-enc-bucket', 'dummy_file_upload.txt')